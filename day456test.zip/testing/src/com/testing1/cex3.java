package com.testing1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class cex3 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("Webdriver.chrom.driver", "C:\\Driver\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions co=new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriver driver=new ChromeDriver(co);
		driver.manage().window().maximize();
		driver.get("https://demo.opencart.com/index.php?route=account/register&language=en-gb");
		WebElement fname=driver.findElement(By.id("input-firstname"));
		fname.sendKeys("Pavithra");
		WebElement lname=driver.findElement(By.cssSelector("input#input-lastname"));
		lname.sendKeys("lakshmi");
		WebElement email=driver.findElement(By.cssSelector("input[placeholder=\"E-Mail\"]"));
		email.sendKeys("pavi123@gmail.com");
		WebElement pass=driver.findElement(By.cssSelector("input.form-control[id=\"input-password\"]"));
		pass.sendKeys("pavi123");
		Thread.sleep(3000);
		WebElement subs=driver.findElement(By.xpath("//input[@id=\"input-newsletter-yes\"]"));
		subs.click();
		driver.findElement(By.name("agree")).click();
	}

}
