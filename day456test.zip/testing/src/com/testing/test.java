package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeOptions co=new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		System.setProperty("Webdriver.chrome.driver", "C:\\Driver\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver =new  ChromeDriver(co);
		driver.get("https://demo.opencart.com/index.php?route=account/register&language=en-gb");
		WebElement fname=driver.findElement(By.id("input-firstname"));
		fname.sendKeys("pavithra");
		WebElement lname=driver.findElement(By.name("lastname"));
		lname.sendKeys("janu");
		WebElement email=driver.findElement(By.name("email"));
		email.sendKeys("janu123");
		WebElement pass=driver.findElement(By.name("password"));
		pass.sendKeys("janu123$");
		driver.findElement(By.id("input-newsletter-yes")).click();
		//driver.findElement(By.name("email")).click();
		//driver.navigate().to("https://www.google.com/");
		//driver.navigate().refresh();
		
		//System.out.println(driver.getTitle());
		
	}
	
	}


